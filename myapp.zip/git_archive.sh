git archive -v -o myapp.zip --format=zip HEAD
